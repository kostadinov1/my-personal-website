// For now, just export EducationSection
export { EducationSection } from './EducationSection';